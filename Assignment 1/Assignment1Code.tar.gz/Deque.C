#include "Deque.h"

/*
Provide all of the implementation for the Deque
class in this file
*/